{{/*
Return the common name for worker components
*/}}
{{/*
Shuffle currently hardcodes the shuffle-workers:33333 address at some places.
Until that can be properly configured, we make sure that the worker deployment and service
are named exactly the same as the deployment and service that orborus would create.
{{- define "shuffle.worker.name" -}}
  {{- printf "%s-worker" (include "common.names.fullname" .) | trunc 63 -}}
{{- end -}}
*/}}
{{- define "shuffle.worker.name" -}}
shuffle-workers
{{- end -}}

{{/*
Return the common labels for worker components deployed via helm.
NOTE: Worker deployments and services use shuffle.workerInstance.labels instead.
*/}}
{{- define "shuffle.worker.labels" -}}
{{- include "common.labels.standard" . }}
app.kubernetes.io/component: worker
{{- end -}}

{{/*
Return the proper Shuffle worker image name
*/}}
{{- define "shuffle.worker.image" -}}
{{- include "common.images.image" ( dict "imageRoot" .Values.worker.image "global" .Values.global "chart" .Chart ) -}}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names for the worker pod
*/}}
{{- define "shuffle.worker.imagePullSecrets" -}}
{{- include "common.images.renderPullSecrets" (dict "images" (list .Values.worker.image) "context" $) -}}
{{- end -}}

{{/*
Create the name of the service account to use for Shuffle workers
*/}}
{{- define "shuffle.worker.serviceAccount.name" -}}
{{- if .Values.worker.serviceAccount.create -}}
    {{ default (include "shuffle.worker.name" .) .Values.worker.serviceAccount.name | trunc 63 | trimSuffix "-" }}
{{- else -}}
    {{ default "default" .Values.worker.serviceAccount.name }}
{{- end -}}
{{- end -}}

{{/*
Return the proper Docker Image Registry Secret Names for the worker service account
*/}}
{{- define "shuffle.worker.serviceAccount.imagePullSecrets" -}}
{{- $pullSecrets := list }}

{{- range .Values.global.imagePullSecrets -}}
    {{- if kindIs "map" . -}}
        {{- $pullSecrets = append $pullSecrets (include "common.tplvalues.render" (dict "value" .name "context" .)) -}}
    {{- else -}}
        {{- $pullSecrets = append $pullSecrets (include "common.tplvalues.render" (dict "value" . "context" .)) -}}
    {{- end -}}
{{- end -}}

{{- range .Values.worker.serviceAccount.imagePullSecrets -}}
    {{- if kindIs "map" . -}}
        {{- $pullSecrets = append $pullSecrets (include "common.tplvalues.render" (dict "value" .name "context" .)) -}}
    {{- else -}}
        {{- $pullSecrets = append $pullSecrets (include "common.tplvalues.render" (dict "value" . "context" .)) -}}
    {{- end -}}
{{- end -}}

{{- if (not (empty $pullSecrets)) -}}
imagePullSecrets:
{{- range $pullSecrets | uniq }}
  - name: {{ . }}
{{- end }}
{{- end }}
{{- end -}}

{{/*
Return the labels to match ALL workers.
These match the labels of helm-deployed workers (shuffle.workerInstance.labels),
as well as orborus-deployed workers (deployk8sworker).
*/}}
{{- define "shuffle.worker.matchLabels" -}}
app.kubernetes.io/name: shuffle-worker
{{- end -}}

{{/*
Return the labels for a specific worker instance deployed via helm.
Usage: 
{{ include "shuffle.workerInstance.labels" (dict "customLabels" $podLabels "context" $) -}}
*/}}
{{- define "shuffle.workerInstance.labels" -}}
{{- $customLabels := mustMerge (dict "app.kubernetes.io/name" "shuffle-worker" "app.kubernetes.io/part-of" "shuffle") (include "common.tplvalues.render" (dict "value" .customLabels "context" .context) | fromYaml) -}}
{{ include "common.labels.standard" (dict "customLabels" $customLabels "context" .context) }}
{{- end -}}

{{/*
Return the labels to match a helm-deployed worker.
Usage: 
{{ include "shuffle.workerInstance.matchLabels" (dict "customLabels" $podLabels "context" $) -}}
*/}}
{{- define "shuffle.workerInstance.matchLabels" -}}
{{- $customLabels := mustMerge (dict "app.kubernetes.io/name" "shuffle-worker" "app.kubernetes.io/part-of" "shuffle") (include "common.tplvalues.render" (dict "value" .customLabels "context" .context) | fromYaml) -}}
{{ include "common.labels.matchLabels" (dict "customLabels" $customLabels "context" .context) }}
{{- end -}}

{{/*
Return a podAffinity/podAntiAffinity definition.
Usage:
{{ include "shuffle.workerInstance.affinities.pods" (dict "type" "soft" "customLabels" $podLabels "context" $) -}}
*/}}
{{- define "shuffle.workerInstance.affinities.pods" -}}
{{- $customLabels := mustMerge (dict "app.kubernetes.io/name" "shuffle-worker" "app.kubernetes.io/part-of" "shuffle") (include "common.tplvalues.render" (dict "value" .customLabels "context" .context) | fromYaml) -}}
{{ include "common.affinities.pods" (dict "type" .type "customLabels" $customLabels "context" .context )}}
{{- end -}}

{{- define "shuffle.worker.hostname" -}}
{{- if .Values.worker.enableHelmDeployment -}}
http://{{ include "shuffle.worker.name" . }}.{{ .Release.Namespace }}.svc.cluster.local
{{- else -}}
http://shuffle-workers.{{ .Release.Namespace }}.svc.cluster.local
{{- end -}}
{{- end -}}

{{- define "shuffle.worker.baseUrl" -}}
{{ include "shuffle.worker.hostname" . }}:{{ .Values.worker.containerPorts.http }}
{{- end -}}

{{/*
Return the environment variables of shuffle-worker in the format
KEY: VALUE

WARNING: Do NOT add environment variables here that would conflict with shuffle.orborus.env.
Orborus also sets all env variables that are defined here, because they will be passed down to worker when orborus.manageWorkerDeployments is set.
Instead, add them directly to the deployment template (shuffle-worker-dpl.yaml).
*/}}
{{- define "shuffle.workerInstance.env" -}}
SHUFFLE_SWARM_CONFIG: "run" # Shuffle Worker requires this to be set even when using K8s instead of swarm
SHUFFLE_APP_EXPOSED_PORT: {{ .Values.app.exposedContainerPort | quote }}
WORKER_HOSTNAME: {{ include "shuffle.worker.hostname" . }}

{{- if .Values.worker.manageAppDeployments }}
# Shuffle app images
REGISTRY_URL: "{{ .Values.shuffle.appRegistry }}"
SHUFFLE_BASE_IMAGE_NAME: "{{ .Values.shuffle.appBaseImageName }}"

# Shuffle app deployment configuration
SHUFFLE_APP_MOUNT_TMP_VOLUME: {{ .Values.app.mountTmpVolume | quote }}
SHUFFLE_APP_SERVICE_ACCOUNT_NAME: {{ include "shuffle.app.serviceAccount.name" . | quote }}
{{- if .Values.app.podSecurityContext.enabled }}
SHUFFLE_APP_POD_SECURITY_CONTEXT: {{ omit .Values.app.podSecurityContext "enabled" | mustToJson | quote }}
{{- end }}
{{- if .Values.app.containerSecurityContext.enabled }}
SHUFFLE_APP_CONTAINER_SECURITY_CONTEXT: {{ include "common.compatibility.renderSecurityContext" (dict "secContext" .Values.app.containerSecurityContext "context" $) | fromYaml | mustToJson | quote }}
{{- end }}

# Shuffle app resources
{{- $appResources := (.Values.app.resources | default (include "common.resources.preset" (dict "type" .Values.app.resourcesPreset) | fromYaml)) -}}
{{- if and $appResources.requests $appResources.requests.cpu }}
SHUFFLE_APP_CPU_REQUEST: {{ $appResources.requests.cpu | quote }}
{{- end }}
{{- if and $appResources.requests $appResources.requests.memory }}
SHUFFLE_APP_MEMORY_REQUEST: {{ $appResources.requests.memory | quote }}
{{- end }}
{{- if and $appResources.requests (index $appResources.requests "ephemeral-storage") }}
SHUFFLE_APP_EPHEMERAL_STORAGE_REQUEST: {{ (index $appResources.requests "ephemeral-storage") | quote }}
{{- end }}
{{- if and $appResources.limits $appResources.limits.cpu }}
SHUFFLE_APP_CPU_LIMIT: {{ $appResources.limits.cpu | quote }}
{{- end }}
{{- if and $appResources.limits $appResources.limits.memory }}
SHUFFLE_APP_MEMORY_LIMIT: {{ $appResources.limits.memory | quote }}
{{- end }}
{{- if and $appResources.limits (index $appResources.limits "ephemeral-storage") }}
SHUFFLE_APP_EPHEMERAL_STORAGE_LIMIT: {{ (index $appResources.limits "ephemeral-storage") | quote }}
{{- end }}

# Include shuffle app environment variables. Worker passes them down to apps, when creating their deployment.
{{ include "shuffle.appInstance.env" (dict "app" .Values.app "context" $) -}}
{{- end }}
{{- end -}}
